"""Configuration system with Pydantic validation."""
