"""Data provider interfaces and implementations."""

