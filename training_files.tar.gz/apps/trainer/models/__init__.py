"""Model architectures for trading."""

