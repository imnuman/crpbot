"""Evaluation framework for trading models."""

