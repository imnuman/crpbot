"""Model training application."""
