"""Training utilities and data loaders."""

